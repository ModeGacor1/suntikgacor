
document.querySelector('.toggle-mode').addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
});


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>All Produk Andre Host</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
  <header>LIST SUNTIK SOSMED BY ANDRE HOST</header>
  
  <!-- BAGIAN VIEWS TIKTOK -->
  <h2>VIEWS TIKTOK</h2>
  <div class="products">
    <div class="card">
      <h3>TIKTOK VIEWS 10K</h3>
      <div class="price">Rp 2.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+10K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 20K</h3>
      <div class="price">Rp 4.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+20K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 30K</h3>
      <div class="price">Rp 6.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+30K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 40K</h3>
      <div class="price">Rp 8.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+40K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 50K</h3>
      <div class="price">Rp 10.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+50K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 60K</h3>
      <div class="price">Rp 12.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+60K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 70K</h3>
      <div class="price">Rp 14.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+70K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 80K</h3>
      <div class="price">Rp 16.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+80K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 90K</h3>
      <div class="price">Rp 18.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+90K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK VIEWS 100K</h3>
      <div class="price">Rp 20.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+VIEWS+TIKTOK+YANG+100K+VIEWS" target="_blank" class="btn-order">ORDER</a>
    </div>
  </div>

  <!-- BAGIAN FOLLOWERS TIKTOK -->
  <h2>FOLLOWERS TIKTOK</h2>
  <div class="products">
    <div class="card">
      <h3>FOLLOWES TIKTOK 100</h3>
      <div class="price">Rp 3.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+3K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 200</h3>
      <div class="price">Rp 6.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+6K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 300</h3>
      <div class="price">Rp 9.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+9K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 400</h3>
      <div class="price">Rp 12.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+12K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 500</h3>
      <div class="price">Rp 15.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+15K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 600</h3>
      <div class="price">Rp 18.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+18K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 700</h3>
      <div class="price">Rp 21.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+21K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 800</h3>
      <div class="price">Rp 24.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+24K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 900</h3>
      <div class="price">Rp 27.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+27K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>FOLLOWES TIKTOK 1000</h3>
      <div class="price">Rp 30.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+FOLLOWERS+TIKTOK+30K" target="_blank" class="btn-order">ORDER</a>
    </div>
  </div>

  <!-- BAGIAN LIKE TIKTOK -->
  <h2>LIKE TIKTOK</h2>
  <div class="products">
    <div class="card">
      <h3>TIKTOK LIKE 100</h3>
      <div class="price">Rp 1.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+1K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKE 200</h3>
      <div class="price">Rp 2.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+2K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKE 300</h3>
      <div class="price">Rp 6.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+3K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKE 400</h3>
      <div class="price">Rp 4.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+4K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKE 500 </h3>
      <div class="price">Rp 5.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+5K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKES 600 + BONUS 2000 VIEWS</h3>
      <div class="price">Rp 6.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+6K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKES 700 + BONUS 2000 VIEWS</h3>
      <div class="price">Rp 7.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+7K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKES 800 + BONUS 2000 VIEWS</h3>
      <div class="price">Rp 8.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+8K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKES 900 + BONUS 2000 VIEWS</h3>
      <div class="price">Rp 9.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+9K" target="_blank" class="btn-order">ORDER</a>
    </div>
    <div class="card">
      <h3>TIKTOK LIKES 1000 + BONUS 2000 VIEWS</h3>
      <div class="price">Rp 10.000</div>
      <a href="https://wa.me/6285169916736?text=HALLO+MAU+ORDER+LIKES+TIKTOK+12K" target="_blank" class="btn-order">ORDER</a>
    </div>

  <script src="script.js"></script>
</body>
</html>
